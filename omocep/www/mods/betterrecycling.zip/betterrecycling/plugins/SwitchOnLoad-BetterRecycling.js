!function(){ 
// Activate switch on load.
let old_loadgame = Scene_OmoriFile.prototype.loadGame

    Scene_OmoriFile.prototype.loadGame = function() {
        old_loadgame.call(this)
        //Sets recycled items correctly
        if ($gameSwitches.value(1860) == 0) {
            $gameSwitches.setValue(1865, true)
            $gameSwitches.setValue(1860, true)
        }
    }
}()