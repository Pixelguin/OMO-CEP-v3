(function() {
    let old = Game_Party.prototype.sortMembersForTag;
    const lut = {
        1: "OMORI",
        2: "AUBREY",
        3: "KEL",
        4: "HERO",
        8: "OMORI",
        9: "AUBREY",
        10: "KEL",
        11: "HERO"
    }
    Game_Party.prototype.sortMembersForTag = function(sanityCheckBase) {
        if (typeof $gameVariables.value(144) === "string") {
            if ($gameVariables.value(144).startsWith("DW") || $gameVariables.value(144).startsWith("FA")) {
                // SANITY CHECK
                if (lut.hasOwnProperty(sanityCheckBase)) {
                    if ($gameVariables.value(144).endsWith(lut[sanityCheckBase])) {
                        AudioManager.playSe({name:$gameVariables.value(144), volume: 100, pitch: 100})
                        $gameVariables.setValue(144, 0);
                    }
                }
            }
        }
        old.bind(this)(...arguments);
    }

    let oldDm = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function() {
        oldDm.bind(this)(...arguments);
        $gameVariables.setValue(144, 0);
    }
})();