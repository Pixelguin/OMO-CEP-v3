(function() {
	/* TODO: Hook ConfigManager.applyData properly so that I can restore toggle
	// Added case 6 for run in background option
	Window_OmoMenuOptionsGeneral.prototype.processOptionCommand = function() {
	  // Get Index
	  var index = this.index();
	  // Get Data
	  var data = this._optionsList[index];
	  // Switch Case Index
	  switch (index) {
		case 0: // Screen Resolution
		  // Set Width & Height
		  Yanfly.Param.ScreenWidth = 640 * (data.index + 1);
		  Yanfly.Param.ScreenHeight = 480 * (data.index + 1) ;
		  SceneManager._screenWidth  = Yanfly.Param.ScreenWidth;
		  SceneManager._screenHeight = Yanfly.Param.ScreenHeight;
		  // SceneManager._boxWidth     = Yanfly.Param.ScreenWidth;
		  // SceneManager._boxHeight    = Yanfly.Param.ScreenHeight
		  Yanfly.updateResolution();
		  Yanfly.moveToCenter();
		  //window.moveTo(x, y);
		  // Set Config Manager Screen Resolution
		  ConfigManager.screenResolution = data.index;
		break;
		case 1: // Fullscreen
		  // Set data Index
		  //data.index === 0 ? Graphics._requestFullScreen() : Graphics._cancelFullScreen();
		  // Set config manager Full screen state
		  ConfigManager.fullScreen = data.index === 0 ? true : false;
		  this._processDelay = 20;
		  //Input.update();
		break;
		case 2: 
		  ConfigManager.gamepadTips = data.index === 0 ? false : true;
		  if(SceneManager._scene instanceof Scene_OmoriTitleScreen) {
			SceneManager._scene.refreshCommandHints(); // Refresh command title hints;
		  }
		  break;
		case 3: ConfigManager.textSkip = data.index === 0 ? true : false; break;
		//case 3: ConfigManager.battleAnimations = data.index === 0 ? true : false ;break;
		//case 4: ConfigManager.battleAnimationSpeed = data.index ;break;
		case 4: ConfigManager.battleLogSpeed = data.index; ;break;
		case 5: ConfigManager.alwaysDash = data.index === 0 ? true : false ;break;
		case 6: 
		  ConfigManager.runInBackground = data.index === 0 ? true : false ;
		  break;
	  };
	};

	// Add run in background when making data
	ConfigManager.makeData = function() {
	  // Get Original Config
	  var config = _TDS_.OmoriBASE.ConfigManager_makeData.call(this);
	  // Set Config Settings
	  config.characterStrafe = this.characterStrafe;
	  config.battleAnimations = this.battleAnimations;
	  config.battleAnimationSpeed = 0;
	  config.battleLogSpeed = this.battleLogSpeed;
	  config.screenResolution = this.screenResolution;
	  config.fullScreen = this.fullScreen;
	  config.menuAnimations = this.menuAnimations;
	  config.keyboardInputMap = Input.keyMapper;
	  config.gamepadInputMap = Input.gamepadMapper;
	  config.gamepadTips = this.gamepadTips;
	  config.textSkip = this.textSkip;
	  config.runInBackground = this.runInBackground;
	  // Return Config
	  return config;
	};
	
	// Add run in background when applying data
	ConfigManager.applyData = function(config) {
	  // Run Original Function
	  _TDS_.OmoriBASE.ConfigManager_applyData.call(this, config);
	  // List of Values to Check
	  var initCheckList = ['characterStrafe', 'battleAnimations',
	  'battleAnimationSpeed', 'battleLogSpeed', 'screenResolution',
	  'fullScreen', 'menuAnimations', 'runInBackground']
	  // Go Through Checl List
	  for (var i = 0; i < initCheckList.length; i++) {
		// Get Name
		var name = initCheckList[i];
		// Set Default value if undefined
		if (config[name] === undefined) { config[name] = this[name]; };
	  };
	  // Set Screen Size
	  Yanfly.Param.ScreenWidth = 640 * (config.screenResolution + 1);
	  Yanfly.Param.ScreenHeight = 480 * (config.screenResolution+ 1) ;
	  SceneManager._screenWidth  = Yanfly.Param.ScreenWidth;
	  SceneManager._screenHeight = Yanfly.Param.ScreenHeight;
	  // SceneManager._boxWidth     = Yanfly.Param.ScreenWidth;
	  // SceneManager._boxHeight    = Yanfly.Param.ScreenHeight
	  //Yanfly.updateResolution();
	  //Yanfly.moveToCenter();
	  this.characterTurning = config.characterTurning;
	  this.characterStrafe = config.characterStrafe;
	  this.battleAnimations = config.battleAnimations;
	  this.battleAnimationSpeed = config.battleAnimationSpeed;
	  this.battleLogSpeed = config.battleLogSpeed === undefined ? 1 : config.battleLogSpeed;
	  this.screenResolution = config.screenResolution;
	  this.fullScreen = config.fullScreen;
	  this.menuAnimations = config.menuAnimations;
	  this.gamepadTips = config.gamepadTips || false;
	  this.textSkip = config.textSkip || false;
	  this.runInBackground = config.runInBackground || false;
	  // Set Input Maps
	  Input.keyMapper = config.keyboardInputMap;
	  Input.gamepadMapper = config.gamepadInputMap;
	  // Set Default keys if undefined
	  if (Input.keyMapper === undefined) { this.setDefaultKeyboardKeyMap(); };
	  if (Input.gamepadMapper === undefined) { this.setDefaultGamepadKeyMap(); };
	  // If Full Screen Request full screen
	  if (config.fullScreen) { 
		Graphics._requestFullScreen(); 
	  }
	  else {
		Yanfly.updateResolution();
		Yanfly.moveToCenter();
	  }
	  
	  

	  if ( $gameSwitches) {
		// If Character Press Turn strafing exists
		if (_TDS_.CharacterPressTurn_Strafing) {
		  // Set Strafe Switch
		  $gameSwitches.setValue(_TDS_.CharacterPressTurn_Strafing.params.strafingDisableSwitchID, this.characterStrafe);
		  // Set Turning Switch
		  $gameSwitches.setValue(_TDS_.CharacterPressTurn_Strafing.params.pressDisableSwitchID, this.characterTurning)
		};
	  };
	};
*/

	// Set isFocus to be true if run in background is true
	SceneManager = class extends SceneManager {

		static update(deltaTime) {
			Graphics.tickStart();
			try {
				const n = this.determineRepeatNumber(deltaTime);
				for (let i = 0; i < n; i++) {
					this.updateManagers();
					this.updateMain();
				}
			} catch (e) {
				this.catchException(e);
			}
			this.renderScene();
			Graphics.tickEnd();
		}

		static determineRepeatNumber(deltaTime) {
			this._smoothDeltaTime *= 0.8;
			this._smoothDeltaTime += Math.min(deltaTime, 2) * 0.2;
			if (this._smoothDeltaTime >= 0.9) {
				this._elapsedTime = 0;
				return Math.round(this._smoothDeltaTime);
			} else {
				this._elapsedTime += deltaTime;
				if (this._elapsedTime >= 1) {
					this._elapsedTime -= 1;
					return 1;
				}
				return 0;
			}			
		}


		static requestUpdate() {
			if (!this.ticker) {
				this.ticker = new PIXI.ticker.Ticker();
				this.ticker.maxFPS = 60;
				this.ticker.add(this.update, this); 
				this.ticker.start();
				// Make On Minimize Event
				const nw = require("nw.gui");
				const win = nw.Window.get();
				const os = require("os");
				win.on("minimize", () => {
					this._minimizeHandler = setInterval(() => {
						if(WebAudio._masterVolume <= 0) {clearInterval(this._minimizeHandler)}
						this.updateWebAudio();
						this.updateVideos();
					}, 25)
				})
				if(os.platform() === "darwin") {
					win.on("blur", () => {
						this._minimizeHandler = setInterval(() => {
							if(WebAudio._masterVolume <= 0) {clearInterval(this._minimizeHandler)}
							this.updateWebAudio();
							this.updateVideos();
						}, 25)
					})					
				}
				win.on("restore", () => {this._clearMinimizeHandler()})
				return;
			}
			else {
				if(this._stopped && this.ticker.started) {this.ticker.stop();}
				else if(!this.ticker.started) {this.ticker.start();}
				return;
			}
		}

		static _clearMinimizeHandler() {
			if(!!this._minimizeHandler) {
				clearInterval(this._minimizeHandler);
				this._minimizeHandler = undefined;
			}
		}

		static tickStart() {}
		static tickEnd() {}

		static stop() {
			this.ticker.stop();
			this._stopped = true;
		}

		static updateMain() {
			this.updateOverlayFix();
			this.updateInputData();
			this.changeScene();
			this.updateScene();
			this.updateWebAudio();
			this.updateVideos();
		}

		static updateOverlayFix() {
			if(!!Graphics._overlayFix) {
				if(Graphics.frameCount % 2 === 0) {
					let ctx = Graphics._overlayFix.getContext("2d");
					ctx.clearRect(0,0,window.screen.width, window.screen.height);
				}
			}
		}

		static updateInputData() {
			if(!this.isFocus()) {return;}
			return super.updateInputData();
		}

		static updateWebAudio() {
			if(!!this.isFocus()) {
				if(WebAudio._context.state === "suspended") {
					this._clearMinimizeHandler();
					WebAudio._context.resume();
				}
				WebAudio.setMasterVolume(Math.min(WebAudio._masterVolume + 0.05, 1));
			}
			else if(!this.isFocus()) {
				WebAudio.setMasterVolume(Math.max(WebAudio._masterVolume - 0.05, 0));
				if(WebAudio._masterVolume <= 0 && WebAudio._context.state !== "suspended") {WebAudio._context.suspend();}
			}
		}

		static updateVideos() {
			if(!this.isFocus()) {
				if(!!Graphics.isVideoPlaying()) {Graphics._video.pause();}
				return ysp.VideoPlayer.pauseVideos();
			}
			else if(!!this.isFocus()) {
				if(Graphics.isVideoPlaying() && Graphics._video.currentTime < Graphics._video.duration) {
					//Graphics._video.volume = !!Graphics._video.volume ? Graphics._video.volume * (ConfigManager.bgmVolume / 100) : 1;
					Graphics._video.play()
				}
				return ysp.VideoPlayer.playVideos();
			}
		}

		static isFocus() {
			/*
			if (ConfigManager.runInBackground)
				return true;
			// Check if there is game focus
			try {
				let neededVisibilityCheck = Utils.isMac() ? true : (document.visibilityState !== "hidden")
				return window.top.document.hasFocus() && neededVisibilityCheck;
			} catch(e) {
				return true; // Safe measure;
			}
			*/
			return true;
		}

		static updateScene() {
			if (this._scene) {
				if (!this._sceneStarted && this._scene.isReady()) {
					this._scene.start();
					this._sceneStarted = true;
					this.onSceneStart();
				}
				if (this.isCurrentSceneStarted() && !!this.isFocus()) {
					this._scene.update();
				}
			}
		}

		static renderScene() {
			if(!this.isFocus()) {return;}
			return super.renderScene();
		}

		static onKeyDown(event) {
			if(Utils.isOptionValid("test")) {return super.onKeyDown(event);}
			if(event.keyCode !== 116) {return super.onKeyDown(event)}
		}

		static snapForBackground(forceAppear = true) {
			if(!!SceneManager.isNextScene(Scene_Battle)) {return;}
			if(!!$gameParty.inBattle()) {
				let spriteset = this._scene._spriteset;
				if(spriteset.battleback1Name() === '' && spriteset.battleback2Name() === '') {return}
			}
			this._backgroundBitmap = this.snap();
			if(!SceneManager.isNextScene(Scene_Menu) && forceAppear) {
				this._backgroundBitmap.blur();	
			}	
		}
	}
})();
