(function() {
	// Changed gamepadTips to not be a boolean
	Window_OmoMenuOptionsGeneral.prototype.processOptionCommand = function() {
	  // Get Index
	  var index = this.index();
	  // Get Data
	  var data = this._optionsList[index];
	  // Switch Case Index
	  switch (index) {
		case 0: // Screen Resolution
		  // Set Width & Height
		  Yanfly.Param.ScreenWidth = 640 * (data.index + 1);
		  Yanfly.Param.ScreenHeight = 480 * (data.index + 1) ;
		  SceneManager._screenWidth  = Yanfly.Param.ScreenWidth;
		  SceneManager._screenHeight = Yanfly.Param.ScreenHeight;
		  // SceneManager._boxWidth     = Yanfly.Param.ScreenWidth;
		  // SceneManager._boxHeight    = Yanfly.Param.ScreenHeight
		  Yanfly.updateResolution();
		  Yanfly.moveToCenter();
		  //window.moveTo(x, y);
		  // Set Config Manager Screen Resolution
		  ConfigManager.screenResolution = data.index;
		break;
		case 1: // Fullscreen
		  // Set data Index
		  //data.index === 0 ? Graphics._requestFullScreen() : Graphics._cancelFullScreen();
		  // Set config manager Full screen state
		  ConfigManager.fullScreen = data.index === 0 ? true : false;
		  this._processDelay = 20;
		  //Input.update();
		break;
		case 2: 
		  ConfigManager.gamepadTips = data.index;// === 0 ? false : true;
		  if(SceneManager._scene instanceof Scene_OmoriTitleScreen) {
			SceneManager._scene.refreshCommandHints(); // Refresh command title hints;
		  }
		  break;
		case 3: ConfigManager.textSkip = data.index === 0 ? true : false; break;
		//case 3: ConfigManager.battleAnimations = data.index === 0 ? true : false ;break;
		//case 4: ConfigManager.battleAnimationSpeed = data.index ;break;
		case 4: ConfigManager.battleLogSpeed = data.index; ;break;
		case 5: ConfigManager.alwaysDash = data.index === 0 ? true : false ;break;
	  };
	};
	
	// Use config instead of controller detection for button prompts
	Bitmap.prototype.determineVendorRect = function() {
	  /*let gamepads = navigator.getGamepads();
	  let currentGamepad;
	  currentGamepad = !Input._lastGamepad ? gamepads[0] : gamepads[Input._lastGamepad];
	  if(!currentGamepad) {return 0;}*/
	  let rectChange = 72;
	  let index = 2; // O - Default; 1 - SONY; 2 - XBOX, -1 Special Mapping;
	  switch(ConfigManager.gamepadTips) {
		case 1: // Xbox
			index = 2;
			break;
		case 2: // Steam Deck
			index = -2;
			break;
		case 3: // PS5
			index = 1;
			break;
		case 4: // PS4
			index = -1;
			break;
		case 5: // Switch
			index = 0;
			break;
		default: // Default to Xbox
			index = 2;
	  }
	  /*
	  let gId = currentGamepad.id.toLowerCase();
	  if(gId.contains("0810") && gId.contains("e501")) {index = -1;} // Particular unbranded controllers;
	  else if(gId.contains("0079") && gId.contains("0011")) {index = -1;} // Dragon Inc
	  else if(gId.contains("054c")) {index = 1;} // SONY
	  else if(gId.contains("045e")) {index = 2;} // MICROSOFT
	  else if(gId.contains("xbox")) {index = 2;} // XBOX
	  else if(gId.contains("playstation")) {index = 1;} // PLAYSTATION
	  else if(gId.contains("ps2")) {index = 1;} // PLAYSTATION
	  else if(gId.contains("ps3")) {index = 1;} // PLAYSTATION
	  else if(gId.contains("ps4")) {index = 1;} // PLAYSTATION
	  else if(gId.contains("ps5")) {index = 1;} // PLAYSTATION
	  else if(currentGamepad.mapping === "standard") {index = 2}
	  */
	  return rectChange * index;
	}
	
	// Added refresh to window when hovering over category to update button prompts
	Window_OmoMenuOptionsCategory.prototype.callUpdateHelp = function() {
	  // Run Original Function
	  Window_Command.prototype.callUpdateHelp.call(this);

	  if (this._optionWindows) {
		// Get Index
		var index = this.index();
		for (var i = 0; i < this._optionWindows.length; i++) {
		  this._optionWindows[i].visible = i === index;
		  this._optionWindows[i].refresh();
		};
	  };
	};
	
	// Added cursor sounds when going left/right through options
	Window_OmoMenuOptionsGeneral.prototype.cursorRight = function(wrap) {
	  // Super Call
	  Window_Selectable.prototype.cursorRight.call(this, wrap);
	  // Get Data
	  var data = this._optionsList[this.index()];
	  // Get Data
	  if(this.index() === 0 && !Graphics._isFullScreen()) {
		SoundManager.playBuzzer();
		return;
	  }  
	  else
		SoundManager.playCursor();
	  if (data) {
		// Set Data Index
		data.index = (data.index + 1) % data.options.length;
		// Process Option Command
		this.processOptionCommand();
		// Update Cursor
		this.updateCursor();
	  }
	};
	
	Window_OmoMenuOptionsGeneral.prototype.cursorLeft = function(wrap) {
	  // Super Call
	  Window_Selectable.prototype.cursorLeft.call(this, wrap);
	  // Get Data
	  var data = this._optionsList[this.index()];
	  // Get Data
	  if(this.index() === 0 && !Graphics._isFullScreen()) {
		SoundManager.playBuzzer();
		return;
	  } 
	  else
		SoundManager.playCursor();
	  if (data) {
		// Get Max Items
		var maxItems = data.options.length;
		// Set Data Index
		data.index = (data.index - 1 + maxItems) % maxItems;
		// Process Option Command
		this.processOptionCommand();
		// Update Cursor
		this.updateCursor();
	  };
	};
	
	// Draw rows of 3
	Window_OmoMenuOptionsGeneral.prototype.drawOptionSegment = function(header, options, spacing, rect) {
	  // Draw Header
	  this.contents.drawText(header, rect.x + 50, rect.y, rect.width, 24);
	  // Go Through Options
	  for (var i = 0; i < options.length; i++) {
		// Draw Options
		if (i < 3)
			this.contents.drawText(options[i], rect.x + (100 + (i * spacing)), rect.y + 35, rect.width, 24);
		else
			this.contents.drawText(options[i], rect.x + (100 + ((i-3) * spacing)), rect.y + 70, rect.width, 24);
	  };
	};
	
	// Change height of row, also used for calculating max rows per page
	Window_OmoMenuOptionsGeneral.prototype.itemHeight = function() { return 99; };
	
	// Change row height to not be the same for all rows
	Window_OmoMenuOptionsGeneral.prototype.itemRect = function(index) {
		var rect = new Rectangle();
		var maxCols = this.maxCols();
		rect.width = this.itemWidth();
		if (index <= 2)
			rect.height = this.itemHeight() - 24;
		else
			rect.height = this.itemHeight();
		rect.x = index % maxCols * (rect.width + this.spacing()) - this._scrollX;
		rect.y = Math.floor(index / maxCols) * rect.height - this._scrollY;
		return rect;
	};
	
	// Draw cursors as rows of 3
	Window_OmoMenuOptionsGeneral.prototype.updateCursor = function() {
	  // Run Original Function
	  Window_Selectable.prototype.updateCursor.call(this);
	  // Get Top Row
	  var topRow = this.topRow();
	  // Get Index
	  var index = this.index();
	  // If Option cursors Exist
	  if (this._optionCursors) {
		// Go through Option Cursors
		for (var i = 0; i < this._optionCursors.length; i++) {
		  // Get Sprite
		  var sprite = this._optionCursors[i];
		  // Get Real Index
		  var realIndex = topRow + i;
		  // Get Data
		  var data = this._optionsList[realIndex];
		  // Get Selected State
		  var selected = this.active ? realIndex === index : false;
		  // If Data Exists
		  if (data) {
			// Get Item Rect
			var rect = this.itemRect(realIndex);
			// Set Sprite Color
			sprite.setColorTone(selected ? [0, 0, 0, 0] : [-80, -80, -80, 255])
			// Activate Selected Sprite
			selected ? sprite.activate() : sprite.deactivate();
			// Set Sprite Positions
			if (data.index < 3)
			{
				sprite.x = (rect.x + 65) +  (data.index * data.spacing);
				sprite.y = rect.y + 60;
			}
			else
			{
				sprite.x = (rect.x + 65) +  ((data.index-3) * data.spacing);
				sprite.y = rect.y + 95;
			}
			// Make Sprite Visible
			sprite.visible = this.height >= sprite.y + sprite.height;
		  } else {
			// Deactivate Sprite
			sprite.deactivate();
			// Make Sprite Invisible
			sprite.visible = false;
		  };
		};
	  }
};
})();
