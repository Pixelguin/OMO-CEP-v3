 (function() {
    
    function Window_MyWindow() {
     this.initialize.apply(this, arguments);
    }
    
    Window_MyWindow.prototype = Object.create(Window_Base.prototype);
    Window_MyWindow.prototype.constructor = Window_MyWindow;
    
    Window_MyWindow.prototype.initialize = function(x, y, width, height) {
        Window_Base.prototype.initialize.call(this, x, y, width, height);
        this.refresh();
		if ($gameVariables.value(1071) == 1) {
		this.drawIcon(28,-5,-6);
		}
		if ($gameVariables.value(1071) == 2) {
		this.drawIcon(29,-5,-6);
		}
		if ($gameVariables.value(1071) == 3) {
		this.drawIcon(30,-5,-6);
		}
		if ($gameVariables.value(1071) == 4) {
		this.drawIcon(31,-5,-6);
		}
	};
    
    Window_MyWindow.prototype.refresh = function() {
		this.contents.clear();
        this.drawText("Durability =", 33, -16, this.contentsWidth(), this.lineHeight());
		this.drawText($gameVariables.value(1019), 140, -14, this.contentsWidth(), this.lineHeight());
    };
    
    var _Scene_Map_createAllWindows = Scene_Map.prototype.createAllWindows;
    Scene_Map.prototype.createAllWindows = function() {
        _Scene_Map_createAllWindows.call(this);
        this.createDinoWindow();
	};
    
    Scene_Map.prototype.createDinoWindow = function() {
		if ($gameSwitches.value(1216) == true) {
        this._dinoWindow = new Window_MyWindow(440, 0, 200, 55);
		this.addChild(this._dinoWindow);
		if ($gameSwitches.value(1217) == false) {
		this._dinoWindow.openness = 0;
		this._dinoWindow.open();
		} else {
			Window_MyWindow.prototype.close = function() {
            Window_Base.prototype.close.call(this);
           if (!this.isClosed()) {
            this._closing = true;
            }
             this._opening = false;
			};
			Window_MyWindow.prototype.updateClose = function() {
            Window_Base.prototype.updateClose.call(this);
			if (this._closing) {
             this.openness = 0;
              if (this.isClosed()) {
               this._closing = false;
			}
		}
    };
	}
		}
	};
    
 })();